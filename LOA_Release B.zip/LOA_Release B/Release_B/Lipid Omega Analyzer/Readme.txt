Lipid Omega Analyzer (LOA) is a software for lipid analysis with specificity of C=C locations.  LOA requires Windows with .net framework 4.0 or later versions.

Instruction on installation:
1. Unzip LOA_Release B.zip and all the files will be located in a folder ��Release_B�� 
2. Double click 'LOA.exe' located in "Lipid Omega Analyzer" subfolder to run the program

Help

Step 1. Subclass of the lipids

1.Click ��Load Data�� in ��Subclass analysis�� to load the ��.xxxx.class.mgf�� file.
2.Click ��Calculate�� in ��Subclass analysis�� to process the data. 
The lipid subclass information, associated retention time, and molecular weight will show in the display window. 

Step 2. Acyl chains of the lipids

3.Click ��Load Data�� in ��Chain analysis�� to load the ��xxxx.chain.mgf�� file.
4.Click ��Calculate�� in ��Chain analysis�� to process the data. 
The acyl chain information of the lipids, associated retention time, m/z of the precursor ion, and molecular weight will show in the display window. 

Step 3. C=C locations in lipids

5.Click ��Load Data�� in ��Double bond analysis�� to load ��xxxx.chain.mgf�� file.
6.Click the ��Calculate�� in ��Double bond analysis�� to process the data. 
The C=C locations for each lipid, associated retention time, molecular weight and the m/z of the precursor ion will show in the display window.
To view the diagnostic spectrum of a specific lipid, click �� View Spectrum�� in right column. Diagnostic ion pairs are labeled with different colors.

To analyze another set of data, click "Reset Data"
